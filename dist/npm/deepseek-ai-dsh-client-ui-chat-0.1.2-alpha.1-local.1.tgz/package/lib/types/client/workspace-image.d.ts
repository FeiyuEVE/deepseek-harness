/** Workspace-relative image resolution for Markdown and the file preview. */
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { SessionReadWorkspaceFileBinaryRequest, SessionReadWorkspaceFileBinaryValue } from '@deepseek-ai/dsh-api-session-controller/types';
import { type SnapshotStore } from '@deepseek-ai/dsh-client-store';
/** Whole-file image reader bound to the Session Remote, supplied through the Chat inject face. */
export type WorkspaceImageReader = (request: SessionReadWorkspaceFileBinaryRequest, signal: AbortSignal) => Promise<RemoteResult<SessionReadWorkspaceFileBinaryValue>>;
/**
 * Whether a file path names a browser-renderable image.
 * @param path - absolute or authored file path.
 * @returns whether the extension is in the renderable set.
 */
export declare function isWorkspaceImagePath(path: string): boolean;
/**
 * Resolve one authored image source (relative paths and `./` prefixes) into
 * an absolute Host path against the Session workspace; non-image sources and
 * absolute HTTP(S) URLs return undefined (the renderer handles those itself).
 * @param cwd - Session workspace root; absent means no resolution.
 * @param src - the authored image destination.
 * @returns the absolute Host path, or undefined when unresolvable.
 */
export declare function resolveWorkspaceImagePath(cwd: string | undefined, src: string): string | undefined;
/**
 * Decode one base64 image payload into a browser URL the `<img>` can load:
 * an object URL when the browser supports it (preferred, revocable), else a
 * data URI. Shared by the Markdown image resolver and the file preview.
 */
export declare function imageDataUrl(mediaType: string, base64: string): string;
/**
 * Session-scoped workspace-image URL cache: one blob URL per resolved path,
 * eagerly loaded on first request, and a reactive version counter so owners
 * can re-render when a lazy load lands (the plain alt-text fallback then
 * swaps to the real image). Failed loads cache as `undefined` so a dead path
 * is not re-read on every render.
 */
export declare class WorkspaceImageUrlCache {
    private readonly reader;
    /** Bumped on every settled load; observe to re-render resolved images. */
    readonly version: SnapshotStore<number>;
    private readonly urls;
    private readonly pending;
    /**
     * @param reader - whole-file image reader; null disables workspace images
     * (then every peek resolves nothing and no read is started).
     */
    constructor(reader: WorkspaceImageReader | null);
    /**
     * Read the cached URL for one path, starting the load on first use.
     * @param path - absolute Host image path.
     * @returns the current URL, or undefined while the read is in flight or failed.
     */
    peek(path: string): string | undefined;
    /** Start the read for one path unless it is cached, pending, or disabled. */
    private load;
    /** Release every object URL and clear the cache (Session-scope disposal). */
    dispose(): void;
}
//# sourceMappingURL=workspace-image.d.ts.map