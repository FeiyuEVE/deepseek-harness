import type { ChatNodeOwnerProps, ChatViewSlotProps } from '../contract/slots.ts';
import type { MarkdownViewMode } from '../../chat-settings.ts';
interface ChatNodeSeatProps extends Omit<ChatNodeOwnerProps, 'markdownView' | 'toggleMessageRaw'> {
    readonly nodeKey: string;
    readonly historyIncomplete: boolean;
    readonly compactTranscript: boolean;
    /** Persisted Markdown presentation before a per-message override. */
    readonly markdownViewDefault: MarkdownViewMode;
    /** Workspace-aware Markdown image resolver (identity moves when a load settles). */
    readonly resolveImage: (src: string) => string | undefined;
    readonly useChat: ChatViewSlotProps['useChat'];
    readonly useStore: ChatViewSlotProps['useStore'];
    readonly actions: ChatViewSlotProps['actions'];
    readonly renderSlot: ChatViewSlotProps['renderSlot'];
    readonly t: ChatViewSlotProps['t'];
}
/** Subscribe, apply Turn-process visibility, and dispatch one stable Context key. */
export declare const ChatNodeSeat: import("react").MemoExoticComponent<({ nodeKey, historyIncomplete, compactTranscript, markdownViewDefault, resolveImage, selectedCallId, cwd, openFile, inspectCall, forkAt, renderMessageImages, fileMentions, useChat, useStore, actions, renderSlot, t, }: ChatNodeSeatProps) => import("react").JSX.Element | null>;
export {};
//# sourceMappingURL=ChatNodeSeat.d.ts.map