/** In-page file preview: chunked reading with a three-chunk sliding window. */
import type { ChatViewSlotProps } from '../contract/slots.ts';
import type { WorkspaceFileReader } from '../file-preview.ts';
import { type WorkspaceImageReader } from '../workspace-image.ts';
/** Format a byte count for the preview header. */
export declare function formatFileSize(bytes: number | undefined): string;
/** File base name for the preview header. */
export declare function fileBaseName(path: string): string;
/** Props of the preview host rendered by the Chat view. */
export interface FilePreviewHostProps {
    useStore: ChatViewSlotProps['useStore'];
    actions: ChatViewSlotProps['actions'];
    readWorkspaceFile: WorkspaceFileReader | null;
    readWorkspaceFileBinary: WorkspaceImageReader | null;
    t: ChatViewSlotProps['t'];
}
/** Renders the open preview overlay, or nothing when the store has none. */
export declare const FilePreviewHost: import("react").MemoExoticComponent<({ useStore, actions, readWorkspaceFile, readWorkspaceFileBinary, t, }: FilePreviewHostProps) => import("react").JSX.Element | null>;
/** Full-screen file preview with chunked scrolling. */
export declare function FilePreview({ path, read, readBinary, close, t }: {
    path: string;
    read: WorkspaceFileReader;
    readBinary: WorkspaceImageReader | null;
    close: () => void;
    t: ChatViewSlotProps['t'];
}): import("react").JSX.Element;
//# sourceMappingURL=FilePreview.d.ts.map