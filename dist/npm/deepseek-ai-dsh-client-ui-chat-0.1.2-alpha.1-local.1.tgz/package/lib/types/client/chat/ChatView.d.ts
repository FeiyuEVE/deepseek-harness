import type { ChatViewSlotProps } from '../contract/slots.ts';
/**
 * The chat view slot entry: pure component over the composed props; each
 * ordered business Node crosses the keyed renderer seat.
 */
export declare function ChatView({ useSession, useChat, useSessions, useStore, actions, renderSlot, sessionId, openFile, readWorkspaceFile, readWorkspaceFileBinary, resolveWorkspaceImage, loadOlder, loadImage, openView, chatScroll, forkAt, fileMentions, useTranscriptView, useMarkdownView, useWorkspaceImages, t, }: ChatViewSlotProps): import("react").JSX.Element;
//# sourceMappingURL=ChatView.d.ts.map