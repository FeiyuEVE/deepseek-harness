/** General Settings row for assistant-Markdown presentation. */
import type { SnapshotStore } from '@deepseek-ai/dsh-client-store';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { MarkdownViewMode } from '../../chat-settings.ts';
/** Registration-side Markdown preference face. */
export interface MarkdownViewRowInjected {
    hooks: {
        /** Persisted Markdown preference bound as useMarkdownView. */
        markdownView: SnapshotStore<MarkdownViewMode>;
    };
    /** Change the assistant-Markdown presentation. */
    setMarkdownView: (mode: MarkdownViewMode) => void;
}
/** Full Settings-row props. */
export type MarkdownViewRowProps = PropsRuntime<'settings.general.item'> & PropsLocale<'chat'> & InjectFace<MarkdownViewRowInjected>;
/**
 * Render the assistant-Markdown presentation selector.
 * @param props - composed Settings slot props.
 * @returns the preference row.
 */
export declare function MarkdownViewRow({ useMarkdownView, setMarkdownView, t }: MarkdownViewRowProps): import("react").JSX.Element;
//# sourceMappingURL=MarkdownViewRow.d.ts.map