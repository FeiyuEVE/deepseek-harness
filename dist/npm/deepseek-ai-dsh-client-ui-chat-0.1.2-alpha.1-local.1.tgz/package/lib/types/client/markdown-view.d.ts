/** Host-backed assistant-Markdown presentation policy. */
import { type SnapshotStore } from '@deepseek-ai/dsh-client-store';
import type { SettingsScope } from '@deepseek-ai/dsh-client-ui-settings/client';
import { type ChatSettings, type MarkdownViewMode } from '../chat-settings.ts';
/** Live Markdown presentation preference consumed by Chat and its Settings row. */
export declare class MarkdownViewPolicy {
    private readonly host;
    /** Reactive current mode; defaults to Rendered before Host settings arrive. */
    readonly mode: SnapshotStore<MarkdownViewMode>;
    /**
     * @param host - durable Chat settings scope.
     */
    constructor(host: SettingsScope<ChatSettings>);
    /**
     * Publish and persist one explicit user choice.
     * @param mode - Rendered or raw Markdown presentation.
     */
    setMode(mode: MarkdownViewMode): void;
    /** Adopt the latest accepted Host section without writing it back. */
    private adopt;
}
//# sourceMappingURL=markdown-view.d.ts.map