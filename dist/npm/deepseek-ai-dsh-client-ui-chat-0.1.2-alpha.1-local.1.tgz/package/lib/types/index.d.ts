/** Host registration for browser Chat preferences. */
import type { Context } from '@deepseek-ai/cordis';
export { CHAT_SETTINGS_NAMESPACE, DEFAULT_MARKDOWN_VIEW_MODE, DEFAULT_TRANSCRIPT_VIEW_MODE, MARKDOWN_VIEW_FIELD, MARKDOWN_VIEW_MODES, TRANSCRIPT_VIEW_FIELD, TRANSCRIPT_VIEW_MODES, type ChatSettings, type MarkdownViewMode, type TranscriptViewMode, } from './chat-settings.ts';
/** Register the durable Chat settings section when a provider exists. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map