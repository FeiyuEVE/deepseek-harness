/** Per-Session Chat selection store shared by the transcript and details panel. */
import { type EngineStoreHandle } from '@deepseek-ai/dsh-client-store';
import type { AssistantMessageId, ChatStoreState, SelectionTarget, TurnProcessViewEntry } from './contract/store.ts';
type ChatActions = {
    select: (draft: ChatStoreState, target: SelectionTarget | null) => void;
    setTurnProcessOpen: (draft: ChatStoreState, turn: number, answerStep: number, open: boolean) => void;
    openFilePreview: (draft: ChatStoreState, path: string) => void;
    closeFilePreview: (draft: ChatStoreState) => void;
    /** Set one message's explicit presentation override (true = raw, false = rendered). */
    setMessageRaw: (draft: ChatStoreState, messageId: AssistantMessageId, raw: boolean) => void;
};
/**
 * Resolve the manually expanded answer for one Turn.
 * @param state - Chat store snapshot.
 * @param turn - owning Turn.
 * @returns the Turn's stored entry, when present.
 */
export declare function storedTurnProcessEntry(state: Readonly<ChatStoreState>, turn: number): Readonly<TurnProcessViewEntry> | undefined;
/**
 * Create the Chat selection store handle.
 * @returns a handle instantiated once per rendered Session scope.
 */
export declare function createChatStore(): EngineStoreHandle<ChatStoreState, ChatActions>;
export {};
//# sourceMappingURL=stores.d.ts.map