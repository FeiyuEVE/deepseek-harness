/** Shared General-Settings row: label block plus a Menu-backed value selector. */
import type { ReactNode } from 'react';
/** One selectable value of a {@link PreferenceRow}. */
export interface PreferenceOption<Value extends string> {
    id: Value;
    /** Localized row label inside the open menu. */
    label: string;
}
export interface PreferenceRowProps<Value extends string> {
    /** Localized preference name. */
    title: string;
    /** Localized sentence explaining what the preference controls. */
    description: string;
    /** Localized label of the current value, shown on the closed selector. */
    selectedLabel: string;
    /** Every value the menu offers. */
    options: readonly PreferenceOption<Value>[];
    /** The currently selected value; the menu marks its row. */
    selectedId: Value;
    /** Persist and apply one chosen value. */
    onSelect: (value: Value) => void;
}
/**
 * Render one preference row whose values are mutually exclusive.
 * @param props - localized copy, the offered values, and the selection.
 * @returns the preference row with its selector and menu.
 */
export declare function PreferenceRow<Value extends string>({ title, description, selectedLabel, options, selectedId, onSelect, }: PreferenceRowProps<Value>): ReactNode;
//# sourceMappingURL=PreferenceRow.d.ts.map