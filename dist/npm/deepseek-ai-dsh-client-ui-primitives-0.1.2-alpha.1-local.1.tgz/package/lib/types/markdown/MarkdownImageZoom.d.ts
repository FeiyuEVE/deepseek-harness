import type { MarkdownImageLabels } from './render.tsx';
export { type MarkdownImageLabels } from './render.tsx';
export interface MarkdownImageZoomProps {
    /** The displayed image source (remote URL or resolved workspace URL). */
    src: string;
    /** Accessible image caption. */
    alt: string;
    /** Localized viewer chrome. */
    labels: MarkdownImageLabels;
    /** Close the viewer. */
    onClose: () => void;
}
/**
 * Full-size Markdown image viewer: a dark fixed layer that fits the image to
 * the viewport and leaves the browser's own pinch/scroll zoom untouched for
 * handheld surfaces. Closes on Escape, backdrop press, or the close control;
 * focus moves to the control on open and returns to the opener on close.
 * Rendered through a body portal: an opener inside a transformed or filtered
 * ancestor would otherwise trap the fixed backdrop in that ancestor's box.
 */
export declare function MarkdownImageZoom({ src, alt, labels, onClose }: MarkdownImageZoomProps): import("react").ReactPortal;
//# sourceMappingURL=MarkdownImageZoom.d.ts.map