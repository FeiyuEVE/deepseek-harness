PRAGMA synchronous = FULL;
